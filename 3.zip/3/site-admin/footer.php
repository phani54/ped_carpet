<div class="footer">
  <div class="footer-inner">
    <!-- basics/footer -->
    <div class="footer-content"> &copy; 2018 <a href="javascript:;">Redcarpet Matrimony</a>, All Rights Reserved. </div>
    <!-- /basics/footer -->
  </div>
</div>
<button type="button" id="back-to-top" class="btn btn-primary btn-sm back-to-top"> <i class="fa fa-angle-double-up icon-only bigger-110"></i> </button>
