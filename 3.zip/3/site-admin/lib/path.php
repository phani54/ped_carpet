<?php
define('URL', 'http://redcarpetmatrimony.com/demo/3/site-admin/');
