<?php
define('URL','http://redcarpetmatrimony.com/demo/3/');
define('IURL','//redcarpetmatrimony.com/demo/3/');
